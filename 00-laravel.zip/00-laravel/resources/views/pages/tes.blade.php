<?php

echo "email: $email. password: $pass";

?>