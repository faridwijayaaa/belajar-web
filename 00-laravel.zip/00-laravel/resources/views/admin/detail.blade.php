@extends('admin.template')
@section('title_Web', 'Edit')
@section('content')
    <table class="table table-bordered" width="100%">
        <tr>
            <th>ID MENU</th>
            <th>MENU</th>
            <th>URUTAN</th>
            <th>ID PARENT</th>
        </tr>
        @foreach ($menu as $m)
            {{-- ID MENU : {{ $m->id_menu }}<br>
        MENU : {{ $m->menu }}<br>
        URUTAN : {{ $m->urutan }}<br>
        ID PARENT : {{ $m->parent_id }}<br> --}}
            <tr>
                <td>{{ $m->id_menu }}</td>
                <td>{{ $m->menu }}</td>
                <td>{{ $m->urutan }}</td>
                <td>{{ $m->parent_id }}</td>
            </tr>
        @endforeach
    </table>
@endsection
