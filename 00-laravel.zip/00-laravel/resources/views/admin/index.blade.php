@extends('admin.template')
@section('title_Web', 'Halaman Admin')
@section('content')
    <table class="table table-bordered" width="100%">
        <tr>
            <th>ID</th>
            <th>MENU</th>
            <th>AKSI</th>
        </tr>
        @foreach ($menus as $menu)
            <tr>
                <td>{{ $menu->id_menu }}</td>
                <td>{{ $menu->menu }}</td>
                <td><a href="./admin/detail/{{ $menu->id_menu }}" class="btn btn-primary">Detail</a></td>
            </tr>
        @endforeach
    </table>
@endsection
