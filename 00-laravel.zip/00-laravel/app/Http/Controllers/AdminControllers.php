<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class AdminControllers extends Controller
{
    //
    public function index() {
        $daftar_menu = DB::table('tbmenu')->where('menu', '<>', 'php')->get();
        return view('admin.index', ['menus' => $daftar_menu]);
    }

    public function index2() {
        $daftar_menu = DB::table('tbmenu')->get();
        return view('admin.template', ['menus' => $daftar_menu]);
    }

    public function detail($id_menu) {
        $data['menu'] = DB::table('tbmenu')->where('id_menu', $id_menu)->get();
        return view('admin.detail', $data);
    }
}
