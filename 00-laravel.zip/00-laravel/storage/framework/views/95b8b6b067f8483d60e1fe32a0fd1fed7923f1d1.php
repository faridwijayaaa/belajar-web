<?php $__env->startSection('title_Web', 'Edit'); ?>
<?php $__env->startSection('content'); ?>
    <table class="table table-bordered" width="100%">
        <tr>
            <th>ID MENU</th>
            <th>MENU</th>
            <th>URUTAN</th>
            <th>ID PARENT</th>
        </tr>
        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <tr>
                <td><?php echo e($m->id_menu); ?></td>
                <td><?php echo e($m->menu); ?></td>
                <td><?php echo e($m->urutan); ?></td>
                <td><?php echo e($m->parent_id); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/Programming/belajar-web/00-laravel/resources/views/admin/detail.blade.php ENDPATH**/ ?>