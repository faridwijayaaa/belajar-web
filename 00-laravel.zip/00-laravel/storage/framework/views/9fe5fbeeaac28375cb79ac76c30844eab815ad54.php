<?php

echo "<h1>HELO WORD</h1>";

?><?php /**PATH /home1/Programming/belajar-web/00-laravel/resources/views/tes.blade.php ENDPATH**/ ?>