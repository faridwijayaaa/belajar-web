<?php $__env->startSection('title_Web', 'Halaman Admin'); ?>
<?php $__env->startSection('content'); ?>
    <table class="table table-bordered" width="100%">
        <tr>
            <th>ID</th>
            <th>MENU</th>
            <th>AKSI</th>
        </tr>
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($menu->id_menu); ?></td>
                <td><?php echo e($menu->menu); ?></td>
                <td><a href="./admin/detail/<?php echo e($menu->id_menu); ?>" class="btn btn-primary">Detail</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/Programming/belajar-web/00-laravel/resources/views/admin/index.blade.php ENDPATH**/ ?>