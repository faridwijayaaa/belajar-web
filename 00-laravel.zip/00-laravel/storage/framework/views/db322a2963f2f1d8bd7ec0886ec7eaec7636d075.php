<?php

echo "email: $email. password: $pass";

?><?php /**PATH /home1/Programming/belajar-web/00-laravel/resources/views///pages/tes.blade.php ENDPATH**/ ?>